package com.example.emanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
